from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def beranda():
    return render_template('beranda.html')

@app.route('/daftar')
def daftar():
    return render_template('daftar.html')

@app.route('/masuk')
def masuk():
    return render_template('masuk.html')

if __name__ == '__main__':
    app.run(debug=True)
